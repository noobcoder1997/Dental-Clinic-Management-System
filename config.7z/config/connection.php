<?php

    //Database configuration
    $db_host = 'localhost';
    $db_user = 'root';
    $db_pass = '';
    $db_name = 'clinic';

    // $db_host = 'sql307.infinityfree.com';
    // $db_user = 'if0_37247809';
    // $db_pass = 'IfgvO2BNlcF2sT';
    // $db_name = 'if0_37247809_clinic';
    
    // $db_host = 'localhost';
    // $db_user = 'u992334777_noobcoder';
    // $db_pass = 'noobCoder1234';
    // $db_name = 'u992334777_noobcoder';

    // Create database connection
    $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    date_default_timezone_set('Asia/Manila');

?>
