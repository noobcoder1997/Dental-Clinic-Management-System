<?php
class Session {
    private $user_object_id;

    public function __construct() {
        // Check if session is already started
        if (session_status() == PHP_SESSION_NONE) {
            session_start(); // Start the session only if it's not started
        }
        $this->check_stored_login(); // Check if there's a session already active
    }

    // Login method to set the user details in the session
    public function login($user_object) {
        if ($user_object) {
            // Regenerate session ID to prevent session fixation attacks
            session_regenerate_id();
            $_SESSION['id'] = $user_object['user_id'];  // Store the user ID
            $_SESSION['role'] = $user_object['role'];  // Store the user role (e.g., 'assistant', 'patient', etc.)
            $this->user_object_id = $user_object['user_id'];
        }
        return true;
    }

    // Check if the user is logged in
    public function is_logged_in() {
        return isset($this->user_object_id);
    }

    // Logout the user and clear the session
    public function logout() {
        unset($_SESSION['id']);
        unset($_SESSION['role']);
        unset($this->user_object_id);
        return true;
    }

    // Retrieve the role of the current logged-in user
    public function get_user_role() {
        return isset($_SESSION['role']) ? $_SESSION['role'] : null;
    }

    // Retrieve a specific session variable by key
    public function get($key) {
        if (isset($_SESSION[$key])) {
            return $_SESSION[$key];
        }
        return null; // Return null if the session variable does not exist
    }

    // Check if a stored login exists (useful to persist sessions)
    private function check_stored_login() {
        if (isset($_SESSION['id'])) {
            $this->user_object_id = $_SESSION['id'];
        }
    }
}
?>
