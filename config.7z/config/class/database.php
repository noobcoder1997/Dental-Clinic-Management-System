<?php
class Database {
    private $pdo;

    // Connect to the database
    public function db_connect($dsn, $db_user, $db_pw) {
        try {
            // Establish the PDO connection
            $this->pdo = new PDO($dsn, $db_user, $db_pw);
            // Set the PDO error mode to exception for better debugging
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            // Handle connection error
            die("Connection failed: " . $e->getMessage());
        }
    }

    // Return the PDO connection
    public function getConnection() {
        return $this->pdo;
    }

    // Database query function
    public function db_query($query, $params = []) {
        try {
            // Prepare and execute the query
            $stmt = $this->pdo->prepare($query);
            $stmt->execute($params);
            return $stmt;
        } catch (PDOException $e) {
            // Handle query error
            echo "Query error: " . $e->getMessage();
            return false;
        }
    }

    // Function to create records in a table
    public function create($columns, $values, $tablename) {
        try {
            // Dynamically generate placeholders for the SQL query
            $columnNames = implode(',', $columns);
            $placeholders = implode(',', array_fill(0, count($columns), '?'));
            
            // Prepare and execute the SQL query
            $stmt = $this->pdo->prepare("INSERT INTO {$tablename} ({$columnNames}) VALUES ({$placeholders})");
            return $stmt->execute($values);
        } catch (PDOException $e) {
            // Handle insert error
            echo "Insert error: " . $e->getMessage();
            return false;
        }
    }

    // Function to display records from the table
    public function display($tablename, $limit = null, $params = []) {
        try {
            // Add a LIMIT clause to the query if specified
            $limitClause = $limit ? "LIMIT {$limit}" : "";
            // Prepare the SELECT query
            $stmt = $this->pdo->prepare("SELECT * FROM {$tablename} {$limitClause}");
            // Execute the query with any passed parameters
            $stmt->execute($params);
            
            // Return all results as an associative array (or object if needed)
            return $stmt->fetchAll(PDO::FETCH_OBJ);
        } catch (PDOException $e) {
            // Handle display error
            echo "Select error: " . $e->getMessage();
            return false;
        }
    }

    // Function to fetch a single record by a specified condition (optional)
    public function fetchRow($tablename, $conditions = '', $params = []) {
        try {
            // Prepare the SELECT query with conditions if provided
            $stmt = $this->pdo->prepare("SELECT * FROM {$tablename} WHERE {$conditions}");
            // Execute the query with passed parameters
            $stmt->execute($params);
            
            // Return a single row (or null if no matching record)
            return $stmt->fetch(PDO::FETCH_OBJ);
        } catch (PDOException $e) {
            // Handle fetch error
            echo "Fetch error: " . $e->getMessage();
            return false;
        }
    }

    // Function to update records in a table
    public function update($columns, $values, $tablename, $condition, $conditionValues) {
        try {
            // Dynamically generate the SET clause of the SQL query
            $setClause = implode(", ", array_map(function ($col) { return "{$col} = ?"; }, $columns));
            
            // Prepare the UPDATE query
            $stmt = $this->pdo->prepare("UPDATE {$tablename} SET {$setClause} WHERE {$condition}");
            // Execute the query with the values to update and the condition values
            return $stmt->execute(array_merge($values, $conditionValues));
        } catch (PDOException $e) {
            // Handle update error
            echo "Update error: " . $e->getMessage();
            return false;
        }
    }

    // Function to delete a record in a table
    public function delete($tablename, $condition, $params) {
        try {
            // Prepare and execute the DELETE query
            $stmt = $this->pdo->prepare("DELETE FROM {$tablename} WHERE {$condition}");
            return $stmt->execute($params);
        } catch (PDOException $e) {
            // Handle delete error
            echo "Delete error: " . $e->getMessage();
            return false;
        }
    }

    public function display_appointment($tablename) {
        $stmt = $this->pdo->prepare("SELECT 
                                        CONCAT(register_patient.first_name, ' register_patient.middle_name ', register_patient.last_name) AS patient_name,
                                        CONCAT(dentist.first_name, ' dentist.middle_name ', dentist.last_name) AS dentist_name,
                                        services.service_name,
                                        services.service_price, 
                                        appointment.appointment_date, 
                                        appointment.payment_ref, 
                                        appointment.payment_proof
                                      FROM appointment
                                      INNER JOIN register_patient ON register_patient.register_id = appointment.patient_id
                                      INNER JOIN dentist ON dentist.dentist_id = appointment.dentist_id
                                      INNER JOIN branch ON branch.branch_id = appointment.branch_id
                                      INNER JOIN services ON services.service_id = appointment.service_id"); 
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_OBJ);
    }
    
}
