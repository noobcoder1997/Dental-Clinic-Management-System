<!DOCTYPE html>
<html>
<head>
    <title>
        Print PDF
    </title>
</head>
<body>
    <form method="post" action="generate.php">
        <label>FIRST NAME: </label>
        <input type="text" name="fname">
        <label>LAST NAME: </label>
        <input type="text" name="lname">
        <button type="submit" name="generate_pdf">Generate PDF</button>
    </form>
</body>
</html>