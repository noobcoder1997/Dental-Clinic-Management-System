<?php
include '../config/connection.php';
session_start();

// require_once("fpdf.php");

// require_once('fpdi/src/Fpdi.php');
// require_once('fpdi/src/FpdfTpl.php');
require_once('fpdf.php');
require_once('fpdi/src/autoload.php');

use setasign\Fpdi\FPDI;

// $pdf = new FPDF();
class _PDF extends FPDI
{
var $angle=0;

    function Rotate($angle,$x=-1,$y=-1)
    {
        if($x==-1)
            $x=$this->x;
        if($y==-1)
            $y=$this->y;
        if($this->angle!=0)
            $this->_out('Q');
        $this->angle=$angle;
        if($angle!=0)
        {
            $angle*=M_PI/180;
            $c=cos($angle);
            $s=sin($angle);
            $cx=$x*$this->k;
            $cy=($this->h-$y)*$this->k;
            $this->_out(sprintf('q %.5F %.5F %.5F %.5F %.2F %.2F cm 1 0 0 1 %.2F %.2F cm',$c,$s,-$s,$c,$cx,$cy,-$cx,-$cy));
        }
    }

    function _endpage()
    {
        if($this->angle!=0)
        {
            $this->angle=0;
            $this->_out('Q');
        }
        parent::_endpage();
    }

    function RotatedText($x,$y,$txt,$angle)
    {
        //Text rotated around its origin
        $this->Rotate($angle,$x,$y);
        $this->Text($x,$y,$txt);
        $this->Rotate(0);
    }

// function RotatedImage($file,$x,$y,$w,$h,$angle)
// {
//     //Image rotated around its upper-left corner
//     $this->Rotate($angle,$x,$y);
//     $this->Image($file,$x,$y,$w,$h);
//     $this->Rotate(0);
// }
}
$id = $_POST['patient'];

$stmt1 = $conn->prepare("SELECT * FROM register_patient WHERE register_id = ? ");
$stmt1->bind_param('s', $id);
$stmt1->execute();
$result1 = $stmt1->get_result();
if(mysqli_num_rows($result1) > 0){
    if($row1 = $result1->fetch_assoc()){
    // initiate FPDI
    $pdf = new _PDF('P');
    
    // add a page
    $pdf->AddPage();

    // set the source file
    $pdf->setSourceFile("doc1.pdf");

    // import page 1
    $tplId = $pdf->importPage(1);
    // use the imported page and place it at point 10,10 with a width of 100 mm
    $pdf->useTemplate($tplId, 7, 5, 200);

    // Now, you can add additional content on top of the existing PDF page
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->SetTextColor(148, 0, 211); // Red text color
    //Chief Complaint
    $pdf->SetXY(50, 10); // Set position where text will be inserted
    $pdf->Write(10, 'This is some added text on top of the existing PDF.');
    //Other findings
    $pdf->SetXY(49, 19); // Set position where text will be inserted
    $pdf->Write(10, 'This is some added text on top of the existing PDF.');
    // Now, you can add additional content on top of the existing PDF page
    $pdf->SetFont('Arial', 'B', 9);
    $pdf->SetTextColor(148, 0, 211); // Red text color
    //Date
    $pdf->SetXY(11, 40); // Set position where text will be inserted
    $pdf->Write(10, date('m-d-Y'));
    //Treatment Rendered
    $pdf->SetXY(67, 40); // Set position where text will be inserted
    $pdf->Write(10, date('m-d-Y'));
    //Fee
    $pdf->SetXY(136, 40); // Set position where text will be inserted
    $pdf->Write(10, date('m-d-Y'));
    //Paid
    $pdf->SetXY(156, 40); // Set position where text will be inserted
    $pdf->Write(10, date('m-d-Y'));
    //Balance
    $pdf->SetXY(175, 40); // Set position where text will be inserted
    $pdf->Write(10, date('m-d-Y'));


    $pdf->AddPage();
    
    // import page 2
    $tplId = $pdf->importPage(2);
    // use the imported page and place it at point 10,10 with a width of 100 mm
    $pdf->useTemplate($tplId, 5, 8, 200);

    // Now, you can add additional content on top of the existing PDF page
    $pdf->SetFont('Arial', 'B', 11);
    $pdf->SetTextColor(148, 0, 211); // Red text color
    // $pdf->SetXY(50, 50); // Set position where text will be inserted
    // $pdf->Write(10, 'This is some added text on top of the existing PDF.');
    
    //Patient Name
    $pdf->RotatedText(180,28,strtoupper($row1['first_name']),-90);
    //Patient Name
    $pdf->RotatedText(180,130,'Hello!',-90);
    //Patient Telephone
    $pdf->RotatedText(180, 250,'Hello!',-90);
    //Patient Age
    $pdf->RotatedText(173,25,'Hello!',-90);
    //Patient Sex
    $pdf->RotatedText(173,60,'Hello!',-90);
    //Patient Status
    $pdf->RotatedText(173,118,'Hello!',-90);
    //Patient Occupation
    $pdf->RotatedText(173,180,'Hello!',-90);
    //Patient Phone Number
    $pdf->RotatedText(173,250,'Hello!',-90);
    //Patient Office Address
    $pdf->RotatedText(166,48,'Hello!',-90);
    //Patient Office Telephone No.
    $pdf->RotatedText(166,215,'Hello!',-90);
    //Date
    $pdf->RotatedText(167,260,'Hello!',-90);
    //Line
    $pdf->SetLineWidth(1);
    $pdf->SetDrawColor(148, 0, 211);
    $pdf->Line(50,100,50,90);
    
    $pdf->Output('P', 'doc2.pdf', true);

    // $pdf->SetLineWidth(20);
    // $pdf->SetXY(50, 70);
    // $pdf->Write(10, 'You can add more content here, like images, etc.');
    }   
}    
    

    // $pdf=new PDF();
    // $pdf->AddPage();
    // $pdf->SetFont('Arial','',20);
    // // $pdf->RotatedImage('circle.png',85,60,40,16,45);
   
    // $pdf->Output();

?>